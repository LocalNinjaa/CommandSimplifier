package com.LocalNinja.CommandSimplifier.command;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

public class k extends CommandBase {

    @Override
    public String getCommandName() {
        return "k";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/k <tier>";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) throws CommandException {
        if (sender instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) sender;

            if (args.length > 0) {
                String arg = args[0].toLowerCase();

                if (arg.equals("normal")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_normal");
                } else if (arg.equals("hot")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_hot");
                } else if (arg.equals("burning")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_burning");
                } else if (arg.equals("fiery")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_fiery");
                } else if (arg.equals("infernal")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_infernal");
                } else if (arg.equals("n")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_normal");
                } else if (arg.equals("h")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_hot");
                } else if (arg.equals("b")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_burning");
                } else if (arg.equals("f")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_fiery");
                } else if (arg.equals("i")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joinkuudra kuudra_infernal");
                } else {
                    player.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Invalid kuudra type! Accepted Tiers: " + EnumChatFormatting.GRAY + "Normal, Hot, Burning, Fiery, Infernal"));
                }

            } else {
                player.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Missing arguments! Usage: /k <tier>"));
            }
        }
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }


}
