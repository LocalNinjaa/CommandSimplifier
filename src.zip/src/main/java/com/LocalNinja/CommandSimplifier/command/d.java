package com.LocalNinja.CommandSimplifier.command;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

public class d extends CommandBase {

    @Override
    public String getCommandName() {
        return "d";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/d <floor>";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) throws CommandException {
        if (sender instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) sender;

            if (args.length > 0) {
                String arg = args[0].toLowerCase();

                if (arg.equals("f1")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon CATACOMBS_FLOOR_ONE");
                } else if (arg.equals("f2")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon CATACOMBS_FLOOR_TWO");
                } else if (arg.equals("f3")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon CATACOMBS_FLOOR_THREE");
                } else if (arg.equals("f4")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon CATACOMBS_FLOOR_FOUR");
                } else if (arg.equals("f5")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon CATACOMBS_FLOOR_FIVE");
                } else if (arg.equals("f6")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon CATACOMBS_FLOOR_SIX");
                } else if (arg.equals("f7")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon CATACOMBS_FLOOR_SEVEN");
                } else if (arg.equals("m1")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon MASTER_CATACOMBS_FLOOR_ONE");
                } else if (arg.equals("m2")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon MASTER_CATACOMBS_FLOOR_TWO");
                } else if (arg.equals("m3")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon MASTER_CATACOMBS_FLOOR_THREE");
                } else if (arg.equals("m4")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon MASTER_CATACOMBS_FLOOR_FOUR");
                } else if (arg.equals("m5")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon MASTER_CATACOMBS_FLOOR_FIVE");
                } else if (arg.equals("m6")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon MASTER_CATACOMBS_FLOOR_SIX");
                } else if (arg.equals("m7")) {
                    Minecraft.getMinecraft().thePlayer.sendChatMessage("/joindungeon MASTER_CATACOMBS_FLOOR_SEVEN");
                } else {
                    player.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Invalid Floor Type! Accepted Floor Types: " + EnumChatFormatting.GRAY + "F1, F2, F3, F4, F5, F6, F7, M1, M2, M3, M4, M5, M6, M7"));
                }

            } else {
                player.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Missing arguments! Usage: /d <floor>"));
            }
        }
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }


}
