package com.LocalNinja.CommandSimplifier;

import com.LocalNinja.CommandSimplifier.command.d;
import com.LocalNinja.CommandSimplifier.command.dungeon;
import com.LocalNinja.CommandSimplifier.command.kuudra;
import com.LocalNinja.CommandSimplifier.command.k;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = "CommandSimplifier", version = "1.0.0", acceptedMinecraftVersions = "[1.8.9]")
public class CommandSimplifierMain {

    private Minecraft mc = Minecraft.getMinecraft();
    @Mod.Instance
    public static CommandSimplifierMain instance;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ClientCommandHandler.instance.registerCommand(new kuudra());
        ClientCommandHandler.instance.registerCommand(new k());
        ClientCommandHandler.instance.registerCommand(new d());
        ClientCommandHandler.instance.registerCommand(new dungeon());
        MinecraftForge.EVENT_BUS.register(this);
    }
}
